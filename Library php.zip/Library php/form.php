<?php
$con = mysqli_connect("localhost", "root", "", "mydb");
if (!$con) {
    die("Connection Error: " . mysqli_connect_error());
}

$acc_no = $title = $author = $edition = $publication = "";
$success = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Escape input for potential injection attacks
    $acc_no = mysqli_real_escape_string($con, $_POST["acc_no"]);
    $title = mysqli_real_escape_string($con, $_POST["title"]);
    $author = mysqli_real_escape_string($con, $_POST["author"]);
    $edition = mysqli_real_escape_string($con, $_POST["edition"]);
    $publication = mysqli_real_escape_string($con, $_POST["publication"]);

    $query = "INSERT INTO books (Accession_number, Title, Author, Edition, Publication)
                VALUES ('$acc_no', '$title', '$author', '$edition', '$publication')";

    if (mysqli_query($con, $query)) {
        $success = true;
    } else {
        echo "Error: " . mysqli_error($con);
    }
}

mysqli_close($con);  // Close database connection

?>

<!DOCTYPE HTML>
<html>
<body bgcolor="cyan">
<a href="search.php">
    <button style="float: right;">Search</button>
</a>
<center><h2>Library Management System</h2></center>
<form action="#" method="post">
    <table border="2" align="center" cellpadding="5" cellspacing="5">
        <tr>
            <td align="right">Accession Number:</td>
            <td><input type="text" name="acc_no" size="48" style="height:25px;"></td>
        </tr>
        <tr>
            <td align="right">Title:</td>
            <td><input type="text" name="title" size="48" style="height:25px;"></td>
        </tr>
        <tr>
            <td align="right">Author:</td>
            <td><input type="text" name="author" size="48" style="height:25px;"></td>
        </tr>
        <tr>
            <td align="right">Edition:</td>
            <td><input type="text" name="edition" size="48" style="height:25px;"></td>
        </tr>
        <tr>
            <td align="right">Publication:</td>
            <td><input type="text" name="publication" size="48" style="height:25px;"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" value="Submit">
                <input type="reset" value="Reset"></td>
        </tr>
    </table>
</form>

<?php if ($success) {
    echo "<center><h1 style='color: green;'>Book Data inserted successfully!</h1></center>";
} ?>

</body>
</html>
